from flask import Flask, request, jsonify, send_from_directory
from dotenv import load_dotenv
import os, requests

load_dotenv()  # reads .env
API_KEY = os.getenv("NEWSAPI_KEY")

app = Flask(__name__, static_folder="static")

@app.route('/')
def index():
    # Serve the static index.html at project root
    return send_from_directory('.', 'index.html')

@app.route('/news')
def news():
    topic = request.args.get('topic', '').strip()
    if not topic:
        return jsonify({"error": "No topic provided"}), 400

    # Build URL (you can adjust 'from' param or remove it)
    url = (
        "https://newsapi.org/v2/everything"
        f"?q={requests.utils.quote(topic)}"
        "&sortBy=publishedAt"
        f"&apiKey={API_KEY}"
        "&pageSize=20"
    )

    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
        if data.get("status") != "ok":
            return jsonify({"error": data.get("message", "Failed to fetch")}), 500

        articles = data.get("articles", [])[:15]  # limit results
        result = [{"title": a.get("title"), "url": a.get("url"), "source": a.get("source", {}).get("name")} for a in articles]
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    # For local testing only. For production use a proper server (gunicorn/uwsgi)
    app.run(debug=True, host="127.0.0.1", port=5000)
